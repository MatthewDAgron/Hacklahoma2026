# Deploy TrendVision Frontend to Amazon Web Services

This guide covers two ways to run the Next.js frontend on AWS. **Option B (EC2)** is recommended because this app uses Next.js API routes and needs a Node server; **Option A (Amplify)** can work for static or simple setups.

---

## What You Need Before Starting

- **AWS account** – [Create one](https://aws.amazon.com/free/) if you don’t have it.
- **Node.js 20+** on your machine (for building the zip locally, if you build before packaging).
- **The deployment zip** – Created by the packaging script below.

---

## Step 1: Create the Deployment Package (on your PC)

1. Open PowerShell.
2. Go to the frontend UI folder:
   ```powershell
   cd c:\Users\nasax\hacker\Hacklahoma2026\frontend\ui
   ```
3. Run the packaging script:
   ```powershell
   .\package-for-aws.ps1
   ```
4. You should see: `Created: trendvision-frontend-deploy.zip` in that folder.
5. Keep this zip; you’ll upload it in the AWS steps below.

---

## Option A: AWS Amplify (recommended)

Amplify hosts your Next.js app and handles build + HTTPS.

### A1. Sign in and open Amplify

1. Go to [AWS Console](https://console.aws.amazon.com/).
2. Sign in.
3. In the search bar, type **Amplify** and open **AWS Amplify**.

### A2. Create a new app from zip

1. Click **Create new app** → **Host web app**.
2. Under **Get started**, choose **Deploy without Git**.
3. **App name:** e.g. `trendvision`.
4. **Environment:** leave default (e.g. `production`).
5. Under **Build and test**, leave defaults for now (we’ll set build commands next).
6. Click **Save and deploy** (Amplify will create the app; the first build may fail until we set the build spec).

### A3. Set the build spec (required for Next.js)

1. In the Amplify app, go to **App settings** (left sidebar) → **Build settings**.
2. Click **Edit** on the build spec.
3. Replace the YAML with this (adjust `appRoot` if your zip has a different root):

```yaml
version: 1
applications:
  - frontend:
      phases:
        preBuild:
          commands:
            - npm ci
        build:
          commands:
            - npm run build
      artifacts:
        baseDirectory: .next
        files:
          - '**/*'
      cache:
        paths:
          - node_modules/**/*
      customHeaders:
        - pattern: '**'
          headers:
            - key: 'Cache-Control'
              value: 'no-cache'
    appRoot: ''
```

If your zip has **all app files at the root** (package.json, `app/`, `components/`, etc.), leave `appRoot: ''`. If you zipped a single folder and inside it is the app, set `appRoot` to that folder name (e.g. `appRoot: 'ui'`).

4. **Important:** This app has API routes (`/api/auth/csrf`). If Amplify build fails or doesn’t support server-side Next.js, use **Option B (EC2)** instead.

### A4. (Optional) Environment variables

If your app uses a backend URL:

1. In Amplify: **App settings** → **Environment variables**.
2. Add:
   - **Key:** `NEXT_PUBLIC_DJANGO_URL`
   - **Value:** your Django/backend URL (e.g. `https://your-api.example.com`).
3. Save. Trigger a new build (e.g. **Redeploy this version**).

### A5. Get your app URL

- After a successful build, Amplify shows the app URL (e.g. `https://main.xxxx.amplifyapp.com`).
- Use that URL to open the frontend in a browser.

---

## Option B: Run on EC2 (Node server)

Use this if you want full control or if Amplify doesn’t support your Next.js setup.

### B1. Launch an EC2 instance

1. In AWS Console, go to **EC2** → **Instances** → **Launch instance**.
2. **Name:** e.g. `trendvision-frontend`.
3. **AMI:** **Amazon Linux 2023**.
4. **Instance type:** e.g. `t3.micro` (free tier).
5. **Key pair:** Create new or use existing; **download the `.pem`** and keep it safe.
6. **Network:** Allow **SSH (22)** and **HTTP (80)** from your IP or `0.0.0.0/0` (less secure; use only for testing).
7. **Storage:** 8 GB is enough.
8. Click **Launch instance**.

### B2. Connect and install Node.js

1. In EC2 → **Instances**, select the instance → **Connect** → **SSH client**.
2. Use the shown command (it uses your `.pem` key). Example:
   ```bash
   ssh -i "your-key.pem" ec2-user@<instance-public-IP>
   ```
3. Once logged in, install Node.js 20:
   ```bash
   sudo dnf install -y nodejs
   node -v   # should be v20.x
   ```
   If the default version is old, use:
   ```bash
   curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
   sudo dnf install -y nodejs
   ```

### B3. Upload and run your app

**Option 1 – Upload zip with SCP (from your PC):**

```powershell
scp -i "C:\path\to\your-key.pem" c:\Users\nasax\hacker\Hacklahoma2026\frontend\ui\trendvision-frontend-deploy.zip ec2-user@<instance-public-IP>:~/
```

Then on the EC2 instance:

```bash
cd ~
unzip -o trendvision-frontend-deploy.zip -d trendvision-app
cd trendvision-app
npm install
npm run build
npm start
```

**Option 2 – If the zip contents were at the root:**  
If after `unzip` you see `package.json` in the current directory, skip the `-d trendvision-app` and just run:

```bash
unzip -o trendvision-frontend-deploy.zip
npm install
npm run build
npm start
```

The app will listen on **port 3000**.

### B4. Open port 3000 and test

1. **EC2** → **Security groups** → select the instance’s security group → **Edit inbound rules**.
2. Add rule: **Type** Custom TCP, **Port** 3000, **Source** `0.0.0.0/0` (or your IP).
3. In the browser open: `http://<instance-public-IP>:3000`.

### B5. (Optional) Run in background and use port 80

Run with a process manager so it keeps running after you disconnect:

```bash
sudo npm install -g pm2
cd ~/trendvision-app   # or wherever your app is
pm2 start npm --name "trendvision" -- start
pm2 save
pm2 startup   # run the command it prints (with sudo)
```

To serve on port 80 (so you can use `http://<IP>` without `:3000`):

```bash
sudo dnf install -y nginx
sudo nano /etc/nginx/conf.d/trendvision.conf
```

Add:

```nginx
server {
  listen 80;
  server_name _;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
  }
}
```

Then:

```bash
sudo nginx -t
sudo systemctl enable nginx && sudo systemctl start nginx
```

Open `http://<instance-public-IP>` in your browser.

### B6. (Optional) Environment variable on EC2

If you use a backend URL:

```bash
echo 'export NEXT_PUBLIC_DJANGO_URL=https://your-django-url.com' | sudo tee -a /etc/environment
# Then restart the app: pm2 restart trendvision
```

Or create a `.env.local` in the app directory (same as local):

```bash
cd ~/trendvision-app
echo "NEXT_PUBLIC_DJANGO_URL=https://your-django-url.com" > .env.local
pm2 restart trendvision
```

---

## Summary Checklist

| Step | Action |
|------|--------|
| 1 | Run `.\package-for-aws.ps1` in `frontend\ui` → get `trendvision-frontend-deploy.zip` |
| 2 | Choose **Amplify** (Option A) or **EC2** (Option B). |
| 3 | **Amplify:** Create app → Deploy without Git → upload zip → set build spec and env vars. |
| 4 | **EC2:** Launch instance → SSH in → install Node → upload zip → unzip → `npm install` → `npm run build` → `npm start` (or use pm2 + nginx). |
| 5 | Set `NEXT_PUBLIC_DJANGO_URL` if your frontend talks to a Django/backend API. |

---

## Troubleshooting

- **Build fails on Amplify:** Ensure `appRoot` matches the folder that contains `package.json` in your zip. If Amplify doesn’t support your Next.js features, use EC2 (Option B).
- **EC2 “npm: command not found”:** Install Node with the `dnf` or `rpm` steps in B2.
- **Can’t open site:** Check security group allows HTTP (80) and/or port 3000 from your IP or `0.0.0.0/0`.
- **App crashes after SSH close:** Use `pm2` as in B5 so the app keeps running.

If you tell me whether you prefer Amplify or EC2 and what step you’re on, I can give exact clicks/commands for that step.
