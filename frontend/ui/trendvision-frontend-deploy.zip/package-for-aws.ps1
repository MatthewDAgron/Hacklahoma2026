# Package TrendVision frontend for AWS deployment
# Run from: frontend\ui (where package.json lives)
# Output: trendvision-frontend-deploy.zip in this folder

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
if (-not (Test-Path "$root\package.json")) {
  Write-Error "Run this script from frontend\ui (directory containing package.json)."
  exit 1
}

$outZip = Join-Path $root "trendvision-frontend-deploy.zip"
$tempDir = Join-Path $root "_deploy_package"

# Remove previous artifacts
if (Test-Path $outZip) { Remove-Item $outZip -Force }
if (Test-Path $tempDir) { Remove-Item $tempDir -Recurse -Force }

New-Item -ItemType Directory -Path $tempDir | Out-Null

# Copy everything except build artifacts and secrets
$excludeDirs = @("node_modules", ".next", ".git", ".vercel", "out", "_deploy_package")
$excludeFiles = @(".env.local", ".env.development.local", ".env.production.local")

Get-ChildItem -Path $root -Force | Where-Object {
  $name = $_.Name
  if ($_.PSIsContainer) {
    $name -notin $excludeDirs -and $name -notlike "*.zip"
  } else {
    $name -notin $excludeFiles -and $name -notlike ".env*"
  }
} | ForEach-Object {
  $dest = Join-Path $tempDir $_.Name
  if ($_.PSIsContainer) {
    Copy-Item -Path $_.FullName -Destination $dest -Recurse -Force
  } else {
    Copy-Item -Path $_.FullName -Destination $dest -Force
  }
}

# Remove node_modules/.next if copied from a subfolder (shouldn't happen with above)
foreach ($dir in $excludeDirs) {
  $path = Join-Path $tempDir $dir
  if (Test-Path $path) { Remove-Item $path -Recurse -Force }
}

Compress-Archive -Path "$tempDir\*" -DestinationPath $outZip -Force
Remove-Item $tempDir -Recurse -Force

Write-Host "Created: $outZip"
Write-Host "Upload this zip to AWS (Amplify or EC2). On the server run: npm install && npm run build && npm start"
